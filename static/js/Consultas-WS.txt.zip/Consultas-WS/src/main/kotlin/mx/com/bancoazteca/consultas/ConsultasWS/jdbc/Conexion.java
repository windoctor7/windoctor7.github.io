package mx.com.bancoazteca.consultas.ConsultasWS.jdbc;

import oracle.jdbc.OracleTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Created by Ascari Q. Romo Pedraza on 03/10/2017.
 */
@Component
public class Conexion implements IConexion {

    private static final Logger LOGGER = LoggerFactory.getLogger(Conexion.class);
    private static final String funcion = "{?=call RCREDITO.FNADSSLG0999(?)}";

    private Connection cn;
    private CallableStatement callabe;

    @Autowired
    private DataSource ds;

    public void prepare(String query){
        prepare(query,100);
    }

    public void prepare(String query, int fetchSize) {
        try {
            cn = ds.getConnection();
            cn.setAutoCommit(false);
            callabe = cn.prepareCall(funcion);
            callabe.setFetchSize(fetchSize);
            callabe.registerOutParameter(1, OracleTypes.CURSOR);
            callabe.setString(2, query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public CallableStatement getCallable() {
        return callabe;
    }

    public void cerrarConexion(){
        try {
            cn.close();
            callabe.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
