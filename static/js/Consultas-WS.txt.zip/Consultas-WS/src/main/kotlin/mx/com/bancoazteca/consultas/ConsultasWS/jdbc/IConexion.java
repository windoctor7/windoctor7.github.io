package mx.com.bancoazteca.consultas.ConsultasWS.jdbc;

import java.sql.CallableStatement;

/**
 * Created by B699320 on 03/10/2017.
 */
public interface IConexion {

    void prepare(String query);
    void prepare(String query, int fetchSize);
    CallableStatement getCallable();
    void cerrarConexion();
}
