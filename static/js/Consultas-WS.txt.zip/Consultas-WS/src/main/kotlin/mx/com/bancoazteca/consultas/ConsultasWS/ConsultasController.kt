package mx.com.bancoazteca.consultas.ConsultasWS

import mx.com.bancoazteca.consultas.ConsultasWS.estatus.IConsulta
import mx.com.bancoazteca.consultas.ConsultasWS.events.SseEngine
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import java.util.*

/**
 * Created by Ascari Q. Romo Pedraza - molder.itp@gmail.com on 03/11/2017.
 */
@RestController
class ConsultasController(val consultas:IConsulta) {

    @GetMapping("/consultar")
    fun consultar(){
        val engine = SseEngine()
        val flux = Flux.empty<Map<String,String>>()


        val uuid = UUID.randomUUID().toString()
        engine.emitters[uuid] = Flux.empty()
    }

}