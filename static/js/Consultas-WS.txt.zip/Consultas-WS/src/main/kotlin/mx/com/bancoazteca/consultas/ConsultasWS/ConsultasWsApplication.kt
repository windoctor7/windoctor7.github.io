package mx.com.bancoazteca.consultas.ConsultasWS

import oracle.ucp.jdbc.PoolDataSource
import oracle.ucp.jdbc.PoolDataSourceFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.context.annotation.Bean
import javax.sql.DataSource

@SpringBootApplication
class ConsultasWsApplication  : CommandLineRunner{

    @Autowired
    lateinit var dataSource:DataSource

    override fun run(vararg args: String?) {
        val cn1 = dataSource.connection
        println("conexiones = ${(dataSource as PoolDataSource).availableConnectionsCount}")
    }

    @Bean
    fun dataSource():DataSource {
       val pool = PoolDataSourceFactory.getPoolDataSource()
        pool.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
        pool.setURL("jdbc:oracle:thin:@//10.63.32.15:1521/RCBDDES");
        pool.setUser("JLOPEZP");
        pool.setPassword("JLOPEZP");
        //Setting pool properties
        pool.setInitialPoolSize(5);
        pool.setMinPoolSize(5);
        pool.setMaxPoolSize(10);
        return pool;
    }
}

fun main(args: Array<String>) {
    SpringApplication.run(ConsultasWsApplication::class.java, *args)
}


