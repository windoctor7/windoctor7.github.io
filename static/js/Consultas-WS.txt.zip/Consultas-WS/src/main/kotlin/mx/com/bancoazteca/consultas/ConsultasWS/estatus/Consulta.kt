package mx.com.bancoazteca.consultas.ConsultasWS.estatus

import mx.com.bancoazteca.consultas.ConsultasWS.jdbc.IConexion
import mx.com.bancoazteca.consultas.ConsultasWS.jdbc.MetaDatos
import oracle.jdbc.OracleTypes
import org.springframework.context.ApplicationEventPublisher
import org.springframework.stereotype.Component
import reactor.core.publisher.Flux
import java.sql.CallableStatement
import java.sql.ResultSet
import javax.sql.DataSource

/**
 * Created by Ascari Q. Romo Pedraza - molder.itp@gmail.com on 02/11/2017.
 */

interface IConsulta{
    fun consulta(q:String)
}

@Component
class Consulta(val dataSource:DataSource, val publisher: ApplicationEventPublisher) : IConsulta{

    val funcion = "{?=call RCREDITO.FNADSSLG0999(?)}"
    val fetchSize = 100;

    override fun consulta(q: String){

        val cb = config(dataSource)
        cb.setString(2,q)
        cb.execute()

        val rs:ResultSet = cb.getObject(1) as ResultSet
        val meta = MetaDatos(rs);
        var list = ArrayList<Map<String,String>>()
        var count = 1

        while (rs.next()){
            val data = LinkedHashMap<String, String>()

            for (i in 1 .. meta.numeroColumnas())
                data[meta.nombreColumna(i)] = rs.getString(i) ?: ""

            list.add(data)

            if(count%fetchSize == 0){
                val flux = Flux.fromIterable(list)
                publisher.publishEvent(flux)
                list = ArrayList<Map<String,String>>()
            }

            count++
        }

    }

    private fun config(ds:DataSource):CallableStatement{
        val cnx = dataSource.connection;
        cnx.autoCommit = true

        val cb = cnx.prepareCall(funcion)
        cb.fetchSize = fetchSize
        cb.registerOutParameter(1, OracleTypes.CURSOR)
        return cb
    }

}
