package mx.com.bancoazteca.consultas.ConsultasWS.mappers

import org.springframework.jdbc.core.RowMapper
import java.sql.ResultSet
import java.sql.ResultSetMetaData

/**
 * Created by Ascari Q. Romo Pedraza - molder.itp@gmail.com on 02/11/2017.
 */
class QueryMapper : RowMapper<Map<String,String>> {

    override fun mapRow(rs: ResultSet, rowNum: Int): Map<String, String> {
        val fetch = rs.fetchSize
        val json:LinkedHashMap<String,String> = LinkedHashMap();
        val metaData = rs.metaData
        val columns = metaData.columnCount

        for ( i in 1..columns){
            val name:String = metaData.getColumnName(i)
            val value:String = rs.getString(name) ?: ""
            json[name] = value
        }

        return json
    }


}