package mx.com.bancoazteca.consultas.ConsultasWS.events

import org.springframework.context.event.EventListener
import reactor.core.publisher.Flux
import java.util.concurrent.ConcurrentHashMap

/**
 * Created by Ascari Q. Romo Pedraza - molder.itp@gmail.com on 04/11/2017.
 */
class SseEngine {

    val emitters = ConcurrentHashMap<String, Flux<String>>()

    @EventListener
    fun event(flux:Flux<Map<String,String>>){

    }

}