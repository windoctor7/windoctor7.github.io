package mx.com.bancoazteca.consultas.ConsultasWS.jdbc

import java.sql.ResultSet
import java.sql.ResultSetMetaData

/**
 * Created by Ascari Q. Romo Pedraza - molder.itp@gmail.com on 03/11/2017.
 */
class MetaDatos(val rs:ResultSet) {

    fun metaData():ResultSetMetaData = rs.metaData
    fun nombreColumna(index:Int):String = metaData().getColumnName(index)
    fun numeroColumnas():Int = metaData().columnCount

}